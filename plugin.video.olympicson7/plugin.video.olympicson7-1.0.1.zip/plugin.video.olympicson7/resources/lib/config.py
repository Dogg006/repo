# flake8: noqa
ADDON_ID = 'plugin.video.olympicson7'

API_VER = '1.0'

MARKET_URL = 'https://api.tvapi.com.au/v1/services/market/ip?apikey=af967c4356eca82c65b1820e0a156cd7'
CONTENT_URL = 'https://component-cdn.swm.digital/content/'
CHANNEL_URL = 'https://api.tvapi.com.au//v1/services/schedule/{cid}/playad?apikey=af967c4356eca82c65b1820e0a156cd7&platform=app&device=android&ppid={ppid}'
CATEGORIES_URL = 'https://cdn-api-vod.swmprod.com.au/categories?product=winter2018'
ITEMS_URL = 'https://cdn-api-vod.swmprod.com.au/items?product=winter2018&category={0}'

EPG_URL = 'https://cdn-api-live.swmprod.com.au/v1/epg?type={0}&market={1}&product=winter2018'

CATEGORIES = [
    'On Now',
    'Settings']

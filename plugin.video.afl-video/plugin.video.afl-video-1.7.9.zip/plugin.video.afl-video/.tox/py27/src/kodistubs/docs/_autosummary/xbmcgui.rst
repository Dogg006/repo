xbmcgui
=======

.. automodule:: xbmcgui

   
   
   .. rubric:: Functions

   .. autosummary::
   
      getCurrentWindowDialogId
      getCurrentWindowId
   
   

   
   
   .. rubric:: Classes

   .. autosummary::
   
      Action
      Control
      ControlButton
      ControlCheckMark
      ControlEdit
      ControlFadeLabel
      ControlGroup
      ControlImage
      ControlLabel
      ControlList
      ControlProgress
      ControlRadioButton
      ControlSlider
      ControlSpin
      ControlTextBox
      Dialog
      DialogProgress
      DialogProgressBG
      ListItem
      Window
      WindowDialog
      WindowXML
      WindowXMLDialog
   
   

   
   
   
Kodi Python API
===============

This is Kodi Python API documentation auto-generated from Kodisutubs docstrings.

.. autosummary::
    :toctree: _autosummary

    xbmc
    xbmcaddon
    xbmcgui
    xbmcplugin
    xbmcvfs

.. note:: This is unofficial documentation not from Team Kodi. The official documentation for Kodi Python API
    can be found `here`_.

.. _here: https://codedocs.xyz/xbmc/xbmc/group__python.html
